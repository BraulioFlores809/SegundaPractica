# SegundaPractica
Actividad con intenciones
